import 'package:flutter/material.dart';

void main() {
  runApp(const CallBridgeApp());
}

class Player {
  Player({required this.name});

  String name;
  int total = 0;
  bool opened = false;
}

class RoundEntry {
  RoundEntry({
    required this.values,
    required this.calls,
    required this.success,
  });

  final List<int> values;
  final List<int> calls;
  final List<bool> success;
}

class CallBridgeApp extends StatelessWidget {
  const CallBridgeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Call Bridge Score',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0D1117),
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.blue,
          brightness: Brightness.dark,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF161B22),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
        ),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final names = List.generate(4, (i) => TextEditingController(text: 'Player ${i + 1}'));

  @override
  void dispose() {
    for (final c in names) {
      c.dispose();
    }
    super.dispose();
  }

  void start() {
    final players = names.map((c) {
      final value = c.text.trim();
      return Player(name: value.isEmpty ? 'Player' : value);
    }).toList();

    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => GamePage(players: players)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Call Bridge Score'),
        centerTitle: true,
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              const SizedBox(height: 20),
              const Icon(Icons.style, size: 64),
              const SizedBox(height: 14),
              const Text(
                '4 Player Scorecard',
                style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              const Text(
                'Enter the four player names',
                style: TextStyle(color: Colors.white60),
              ),
              const SizedBox(height: 24),
              ...List.generate(
                4,
                (i) => Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: TextField(
                    controller: names[i],
                    textCapitalization: TextCapitalization.words,
                    decoration: InputDecoration(
                      labelText: 'Player ${i + 1}',
                      prefixIcon: const Icon(Icons.person),
                    ),
                  ),
                ),
              ),
              const Spacer(),
              SizedBox(
                width: double.infinity,
                height: 54,
                child: FilledButton.icon(
                  onPressed: start,
                  icon: const Icon(Icons.play_arrow),
                  label: const Text('START GAME', style: TextStyle(fontSize: 17)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class GamePage extends StatefulWidget {
  const GamePage({super.key, required this.players});

  final List<Player> players;

  @override
  State<GamePage> createState() => _GamePageState();
}

class _GamePageState extends State<GamePage> {
  final List<RoundEntry> history = [];

  final List<TextEditingController> calls =
      List.generate(4, (_) => TextEditingController(text: '0'));
  final List<TextEditingController> points =
      List.generate(4, (_) => TextEditingController(text: '0'));

  final List<bool> success = List.generate(4, (_) => true);

  @override
  void dispose() {
    for (final c in calls) {
      c.dispose();
    }
    for (final c in points) {
      c.dispose();
    }
    super.dispose();
  }

  int _int(String text) => int.tryParse(text.trim()) ?? 0;

  void addRound() {
    final values = <int>[];

    for (int i = 0; i < 4; i++) {
      final call = _int(calls[i]);
      int value;

      if (call == 8) {
        value = success[i] ? 13 : -8;
      } else {
        value = _int(points[i]);
      }

      values.add(value);
    }

    setState(() {
      for (int i = 0; i < 4; i++) {
        final p = widget.players[i];
        final value = values[i];

        // A player whose score has never opened cannot lose points.
        // Once they receive a positive score, negative scores apply normally.
        if (value > 0) {
          p.total += value;
          p.opened = true;
        } else if (value < 0) {
          if (p.opened) {
            p.total += value;
          }
        }
      }

      history.add(
        RoundEntry(
          values: List.from(values),
          calls: List.generate(4, (i) => _int(calls[i].text)),
          success: List.from(success),
        ),
      );
    });

    for (int i = 0; i < 4; i++) {
      calls[i].text = '0';
      points[i].text = '0';
      success[i] = true;
    }
  }

  void undoLast() {
    if (history.isEmpty) return;

    final last = history.removeLast();

    setState(() {
      // Rebuild totals from the beginning so the "score opened" rule
      // remains correct even after undo.
      for (final p in widget.players) {
        p.total = 0;
        p.opened = false;
      }

      for (final round in history) {
        for (int i = 0; i < 4; i++) {
          final value = round.values[i];
          final p = widget.players[i];
          if (value > 0) {
            p.total += value;
            p.opened = true;
          } else if (value < 0 && p.opened) {
            p.total += value;
          }
        }
      }

      for (int i = 0; i < 4; i++) {
        calls[i].text = last.calls[i].toString();
        points[i].text = last.values[i].toString();
        success[i] = last.success[i];
      }
    });
  }

  void resetGame() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Reset game?'),
        content: const Text('All rounds and scores will be cleared.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('CANCEL'),
          ),
          FilledButton(
            onPressed: () {
              Navigator.pop(context);
              setState(() {
                history.clear();
                for (final p in widget.players) {
                  p.total = 0;
                  p.opened = false;
                }
              });
            },
            child: const Text('RESET'),
          ),
        ],
      ),
    );
  }

  Widget playerCard(int i) {
    final p = widget.players[i];
    final call = _int(calls[i].text);

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    p.name,
                    style: const TextStyle(
                      fontSize: 19,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Text(
                  '${p.total}',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: p.total < 0 ? Colors.redAccent : Colors.greenAccent,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: calls[i],
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'Call',
                      prefixIcon: Icon(Icons.call),
                    ),
                    onChanged: (_) => setState(() {}),
                  ),
                ),
                const SizedBox(width: 10),
                if (call == 8)
                  Expanded(
                    child: DropdownButtonFormField<bool>(
                      value: success[i],
                      decoration: const InputDecoration(labelText: 'Result'),
                      items: const [
                        DropdownMenuItem(value: true, child: Text('Success +13')),
                        DropdownMenuItem(value: false, child: Text('Fail -8')),
                      ],
                      onChanged: (v) {
                        if (v != null) setState(() => success[i] = v);
                      },
                    ),
                  )
                else
                  Expanded(
                    child: TextField(
                      controller: points[i],
                      keyboardType: const TextInputType.numberWithOptions(
                        signed: true,
                      ),
                      decoration: const InputDecoration(
                        labelText: 'Score (+ / -)',
                        prefixIcon: Icon(Icons.add),
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              call == 8
                  ? (success[i] ? 'This round: +13' : 'This round: -8')
                  : 'Enter the points to add, e.g. +3 or -3',
              style: const TextStyle(color: Colors.white54, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Game'),
        actions: [
          IconButton(
            tooltip: 'Undo last round',
            onPressed: history.isEmpty ? null : undoLast,
            icon: const Icon(Icons.undo),
          ),
          IconButton(
            tooltip: 'Reset',
            onPressed: resetGame,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(12, 12, 12, 100),
                children: [
                  Row(
                    children: [
                      const Expanded(
                        child: Text(
                          'Current totals',
                          style: TextStyle(
                            fontSize: 21,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      Text(
                        'Rounds: ${history.length}',
                        style: const TextStyle(color: Colors.white54),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  ...List.generate(4, playerCard),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: const BoxDecoration(
                color: Color(0xFF161B22),
                border: Border(top: BorderSide(color: Colors.white12)),
              ),
              child: SizedBox(
                width: double.infinity,
                height: 52,
                child: FilledButton.icon(
                  onPressed: addRound,
                  icon: const Icon(Icons.add),
                  label: const Text(
                    'ADD ROUND',
                    style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
