# Call Bridge Score

A minimal four-player Call Bridge score tracker.

## Rules implemented

- Four players.
- Each round records a call and score.
- Calls 2–7: enter the points directly, positive or negative.
- Call 8:
  - Success = +13.
  - Failure = -8.
- If a player's score has never opened (they have not earned a positive score yet), a negative result is ignored.
- Once a player's score has opened, negative scores are applied normally.
- Running totals are shown immediately.
- Undo the last round.
- Reset the whole game.
- Dark interface.

## Run

Install Flutter, then:

```bash
flutter pub get
flutter run
```

The project can be opened in Android Studio or VS Code.
